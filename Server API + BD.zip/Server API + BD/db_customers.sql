/*
Navicat MySQL Data Transfer

Source Server         : localhost_server
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : db_customers

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2020-08-20 08:54:43
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for master_customer
-- ----------------------------
DROP TABLE IF EXISTS `master_customer`;
CREATE TABLE `master_customer` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `name_customer` varchar(50) DEFAULT NULL,
  `email_customer` varchar(50) DEFAULT NULL,  
  `nit_customer` text,
  `created_at` date DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of master_customer
-- ----------------------------
INSERT INTO `master_customer` VALUES ('1', 'Alex Buitrago', 'abbir_1991@hotmail.com','998898', '2020-08-20','1991-06-12');
INSERT INTO `master_customer` VALUES ('2', 'Claudia Restrepo', 'a1@hotmail.com','101010', '2020-08-20','1993-06-12');
INSERT INTO `master_customer` VALUES ('3', 'Yeison Calderon', 'ertt1@gmail.com','485485', '2020-08-20','1996-09-01');
INSERT INTO `master_customer` VALUES ('4', 'Felipe Segura', 'ab1@hotmail.com','2939349', '2020-08-20','1994-08-02');
INSERT INTO `master_customer` VALUES ('5', 'Manuela Beltran', 'yeja@gmail.com','38484', '2020-08-20','1999-06-12');
INSERT INTO `master_customer` VALUES ('6', 'Lucia Fernandez', 'keidek@gmail.com','93034040', '2020-08-20','1990-05-09');
INSERT INTO `master_customer` VALUES ('7', 'Pedro Urrego', 'mor4e@hotmail.com','49995', '2020-08-20','1995-04-12');

